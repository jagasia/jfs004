package com.cts.hrms.apis;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.hrms.entity.Product;

@FeignClient(url = "http://localhost:5001/product", value = "product-api")
public interface ProductApi {
	@PostMapping
	public Product addProduct(@RequestBody Product product);
	
	@GetMapping
	public List<Product> retrieveAllProducts();
	
	@GetMapping("/{id}")
	public Product findProductById(@PathVariable("id") Integer id);
	
	@PutMapping
	public Product modifyProduct(@RequestBody Product product);
	
	@DeleteMapping("/{id}")
	public Product removeProduct(@PathVariable("id") Integer id);
}

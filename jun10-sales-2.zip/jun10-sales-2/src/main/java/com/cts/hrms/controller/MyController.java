package com.cts.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.hrms.apis.ProductApi;
import com.cts.hrms.entity.Product;

@RestController
public class MyController {
	
	@Autowired
	private ProductApi pa;
	
	@GetMapping("/")
	public String home()
	{
		return "HEllo world";
	}
	
	@GetMapping("/sales/product")
	public List<Product> getAllProducts()
	{
//		pa.findProductById(id)
//		pa.modifyProduct(product)
//		pa.removeProduct(id)
	
		return pa.retrieveAllProducts();
	}
}

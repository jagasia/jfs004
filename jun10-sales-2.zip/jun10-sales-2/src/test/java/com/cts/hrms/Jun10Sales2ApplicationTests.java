package com.cts.hrms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jun10Sales2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

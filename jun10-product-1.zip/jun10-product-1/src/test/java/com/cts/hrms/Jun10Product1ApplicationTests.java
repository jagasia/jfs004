package com.cts.hrms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jun10Product1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
